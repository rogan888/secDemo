package dao.user;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import dao.BaseDao;
import pojo.User;;

public class UserDaoImpl implements UserDao {
	private String password = "nongzx";
	public static void main (String[] args){
	}
	@Override
	public User getLoginUser(Connection conn, User user) throws Exception {
		// TODO Auto-generated method stub

		String sql = "select * from student where name='" + 
		user.getName() + "' and password='" 
				+ user.getPassword()
				+ "'";
		PreparedStatement ps = conn.prepareStatement(sql);
		MessageDigest badDigester = MessageDigest.getInstance("MD5"); // Unsafe
		ResultSet rs = ps.executeQuery(); 
		User user2 = null;
		if (rs.next()) {
			user2 = new User();
			user2.setName(rs.getString("name"));
			user2.setPassword(rs.getString("password"));
			user2.setId(rs.getInt("id"));
		}
		BaseDao.closeResource(conn, ps, rs);
		return user2;
	}
	@Override
	public User getLoginUser1(Connection conn, User user) throws Exception {
		// TODO Auto-generated method stub
//user.setPassword("user");
		String sql = "select * from student where name='" + 
		user.getName() + "' and password='" 
				+ user.getPassword()
				+ "'";
		PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet rs = ps.executeQuery(); 
		User user2 = null;
		if (rs.next()) {
			user2 = new User();
			user2.setName(rs.getString("name"));
			user2.setPassword(rs.getString("password"));
			user2.setId(rs.getInt("id"));
		}
		BaseDao.closeResource(conn, ps, rs);
		return user2;
	}
	public List<User> getUsers5(Connection conn,User user1) throws Exception {
		String sql = "select * from "
				+ "student" + "where name="+user1.getName()+"'";
		
		return null;
	}
	@Override
	public List<User> getUsers(Connection conn) throws Exception {
		String sql = "select * from "
				+ "student" + "where name='" + 4+ "' and password='" 
				+ user.getPassword();
		PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		List<User> list = new ArrayList<User>();
		while (rs.next()) {

			String address = rs.getString("address");
			String name = rs.getString("name");
			int id = rs.getInt("id");
			String password = rs.getString("password");
			User user = new User(id, name, password, address);
			list.add(user);
		}
		return list;
	}

	@Override
	public int addUser(Connection conn, User user) throws Exception {
		String sql = "INSERT INTO student "
				+ "VALUES (null,?,?,?,?)";
		Object[] params = { user.getName(), user.getAge(), user.getPassword(), user.getAddress() };
		int execute = 0;
		execute = BaseDao.execute(conn, null, sql, params);
		BaseDao.closeResource(conn, null, null);
		return execute;
	}
	
	public int addUser1(Connection conn, User user) throws Exception {
		String sql = "INSERT INTO student VALUES (null,?,?,?,?)";
		Object[] params = { user.getName(), user.getAge(), user.getPassword(), user.getAddress() };
		int execute = 0;
		execute = BaseDao.execute(conn, null, sql, params);
		BaseDao.closeResource(conn, null, null);
		return execute;
	}
	public List<User> getUsers(Connection conn,User user1,String str) throws Exception {
		
		String sql = "select * from "
				+ "student" + "where name="+user1.getName()+"'"+str;
		//PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		List<User> list = new ArrayList<User>();
		while (rs.next()) {
			String address = rs.getString("address");
			String name = rs.getString("name");
			int id = rs.getInt("id");
			String password = rs.getString("password");
			User user = new User(id, name, password, address);
			list.add(user);
		}
		return list;
	}
	//没执行语句，不列入验证范围
	public List<User> getUsers4(Connection conn,User user1) throws Exception {
		
		String sql = "select * from "
				+ "student" + "where name="+user1.getName()+"'";
		return null;
		
	}
	
	//被注释，不列为验证范围
	public int addUser2(Connection conn, User user) throws Exception {
//		String sql = "INSERT INTO student VALUES (null,?,?,?,?)";
		Object[] params = { user.getName(), user.getAge(), user.getPassword(), user.getAddress() };
		int execute = 0;
		execute = BaseDao.execute(conn, null, null, params);
		BaseDao.closeResource(conn, null, null);
		return execute;
	}
	//被注释，不列为验证范围
	public int addUser3(Connection conn, User user) throws Exception {
		String sql = "INSERT INTO "
				+ "student VALUES (null,?,?,?,?)";
		Object[] params = { user.getName(), user.getAge(), user.getPassword(), user.getAddress() };
		int execute = 0;
		//execute = BaseDao.execute(conn, null, sql, params);
		BaseDao.closeResource(conn, null, null);
		return execute;
	}

}
