package utils;

public class Constants {
	public static final String CRITICAL ="critical";
	public static final String HIGH ="high";
	public static final String STANDARD ="standard";
}
